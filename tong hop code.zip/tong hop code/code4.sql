CREATE TABLE Device (
    deviceID INT AUTO_INCREMENT,
    registerDate DATE NOT NULL,
    brand VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    employeeID INT NOT NULL,

    CONSTRAINT PK_Device PRIMARY KEY (deviceID),

    CONSTRAINT FK_Device_Employee
        FOREIGN KEY (employeeID)
        REFERENCES Employee(employeeID)
);