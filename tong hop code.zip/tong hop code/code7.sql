CREATE TABLE Service (
    serviceID INT AUTO_INCREMENT,
    serviceName VARCHAR(100) NOT NULL,
    startDate DATE NOT NULL,

    CONSTRAINT PK_Service PRIMARY KEY (serviceID)
);