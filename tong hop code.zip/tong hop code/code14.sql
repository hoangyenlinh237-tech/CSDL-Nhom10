DELIMITER $$

CREATE TRIGGER trg_CheckHireDate
BEFORE INSERT ON Employee
FOR EACH ROW
BEGIN
    IF NEW.hireDate > CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT='Hire Date cannot be in the future';
    END IF;
END$$

DELIMITER ;