CREATE TABLE Server (

    serverID INT AUTO_INCREMENT,
    serverName VARCHAR(100) NOT NULL,
    manufacturer VARCHAR(100) NOT NULL,
    ipAddress VARCHAR(45) NOT NULL,
    operatingSystem VARCHAR(100) NOT NULL,
    serverRoom VARCHAR(50) NOT NULL,

    CONSTRAINT PK_Server PRIMARY KEY (serverID),

    CONSTRAINT UQ_Server_IP UNIQUE (ipAddress)
);