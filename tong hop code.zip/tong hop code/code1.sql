CREATE TABLE Department (
    departmentID INT AUTO_INCREMENT,
    departmentName VARCHAR(100) NOT NULL,
    internalMailbox VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,

    CONSTRAINT PK_Department PRIMARY KEY (departmentID),
    CONSTRAINT UQ_DepartmentName UNIQUE (departmentName)
);